Everything up to 52 works, and gives correct ppm using test8.
So that's a good start.
Note that frechet_k1 was a pain, because of the parameter ordering switching round, which is my stupid fault.
